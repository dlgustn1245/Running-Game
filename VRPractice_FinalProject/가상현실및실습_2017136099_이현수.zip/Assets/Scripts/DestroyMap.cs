using UnityEngine;

public class DestroyMap : MonoBehaviour
{
    void Start()
    {
        Destroy(this.gameObject, 17.5f);
    }
}
